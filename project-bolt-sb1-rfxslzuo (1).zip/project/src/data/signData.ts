// Define the interface for sign language data entries
export interface SignEntry {
  name: string;
  description: string;
  category: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  imageUrl?: string;
}

// Create the sign dictionary data
export const signDictionary: SignEntry[] = [
  // Alphabet Category
  {
    name: 'Letter A',
    description: 'Make a fist with your hand, with your thumb resting on the side of your finger.',
    category: 'alphabet',
    difficulty: 'Beginner'
  },
  {
    name: 'Letter B',
    description: 'Hold your hand up with your palm facing forward and your fingers extended upward, keeping them together.',
    category: 'alphabet',
    difficulty: 'Beginner'
  },
  {
    name: 'Letter C',
    description: 'Curve your hand to form a "C" shape with your thumb and fingers.',
    category: 'alphabet',
    difficulty: 'Beginner'
  },
  {
    name: 'Letter D',
    description: 'Make a circle with your thumb and index finger, while extending your other fingers upward.',
    category: 'alphabet',
    difficulty: 'Beginner'
  },
  {
    name: 'Letter E',
    description: 'Curl your fingers in toward your palm, with your thumb resting against your index finger.',
    category: 'alphabet',
    difficulty: 'Beginner'
  },
  {
    name: 'Letter F',
    description: 'Connect your thumb and index finger in a circle, while extending your other fingers.',
    category: 'alphabet',
    difficulty: 'Beginner'
  },
  {
    name: 'Letter G',
    description: 'Make a fist and extend your index finger, pointing it to the side.',
    category: 'alphabet',
    difficulty: 'Beginner'
  },
  {
    name: 'Letter Z',
    description: 'Make the shape of the letter Z with your index finger, tracing it in the air.',
    category: 'alphabet',
    difficulty: 'Intermediate'
  },
  
  // Numbers Category
  {
    name: 'Number 1',
    description: 'Extend your index finger upward with all other fingers closed in a fist.',
    category: 'numbers',
    difficulty: 'Beginner'
  },
  {
    name: 'Number 2',
    description: 'Extend your index and middle fingers upward with all other fingers closed in a fist.',
    category: 'numbers',
    difficulty: 'Beginner'
  },
  {
    name: 'Number 3',
    description: 'Extend your thumb, index, and middle fingers, keeping other fingers closed.',
    category: 'numbers',
    difficulty: 'Beginner'
  },
  {
    name: 'Number 4',
    description: 'Extend your index, middle, ring, and pinky fingers, keeping your thumb closed against your palm.',
    category: 'numbers',
    difficulty: 'Beginner'
  },
  {
    name: 'Number 5',
    description: 'Extend all five fingers with your palm facing forward.',
    category: 'numbers',
    difficulty: 'Beginner'
  },
  {
    name: 'Number 10',
    description: 'Quickly open and close your hand once, representing the count of "ten".',
    category: 'numbers',
    difficulty: 'Beginner'
  },
  
  // Common Phrases
  {
    name: 'Thank You',
    description: 'Touch your chin or lips with the fingertips of your flat hand, then move your hand forward and down.',
    category: 'common',
    difficulty: 'Beginner'
  },
  {
    name: 'Please',
    description: 'Rub your chest in a circular motion with a flat hand.',
    category: 'common',
    difficulty: 'Beginner'
  },
  {
    name: 'Sorry',
    description: 'Make a fist and rub it in a circular motion over your chest.',
    category: 'common',
    difficulty: 'Beginner'
  },
  {
    name: 'Help',
    description: 'Make a thumbs-up with one hand, then place it on the palm of your other hand and raise both hands.',
    category: 'common',
    difficulty: 'Intermediate'
  },
  {
    name: 'I Love You',
    description: 'Extend your thumb, index finger, and pinky finger while keeping your middle and ring fingers folded down.',
    category: 'common',
    difficulty: 'Beginner'
  },
  
  // Greetings
  {
    name: 'Hello',
    description: 'Raise your hand near your forehead, palm facing out, and move it away in an arc.',
    category: 'greetings',
    difficulty: 'Beginner'
  },
  {
    name: 'Good Morning',
    description: 'Sign "good" by placing your right hand, palm down, on your left palm, then moving it forward. Then sign "morning".',
    category: 'greetings',
    difficulty: 'Intermediate'
  },
  {
    name: 'Goodbye',
    description: 'Wave your open hand back and forth, similar to a traditional goodbye wave.',
    category: 'greetings',
    difficulty: 'Beginner'
  },
  {
    name: 'Nice to Meet You',
    description: 'A combination of signs: "nice", "meet", and pointing to the person you\'re addressing.',
    category: 'greetings',
    difficulty: 'Advanced'
  },
  
  // Emotions
  {
    name: 'Happy',
    description: 'Brush your fingers up from your chest to your face, ending with a smile gesture.',
    category: 'emotions',
    difficulty: 'Beginner'
  },
  {
    name: 'Sad',
    description: 'Place both hands in front of your face, palms inward, and draw them down to simulate tears.',
    category: 'emotions',
    difficulty: 'Beginner'
  },
  {
    name: 'Angry',
    description: 'Place your fingers at the front of your face and pull them back while making an angry facial expression.',
    category: 'emotions',
    difficulty: 'Intermediate'
  },
  {
    name: 'Excited',
    description: 'Make "Y" handshapes with both hands and shake them rapidly.',
    category: 'emotions',
    difficulty: 'Beginner'
  },
  {
    name: 'Tired',
    description: 'Drag both "5" hands down your face from your eyes, ending with a tired expression.',
    category: 'emotions',
    difficulty: 'Beginner'
  },
  
  // Questions
  {
    name: 'What',
    description: 'Shake your index finger side to side with a questioning expression.',
    category: 'questions',
    difficulty: 'Beginner'
  },
  {
    name: 'Where',
    description: 'Wave your index finger around with a questioning expression.',
    category: 'questions',
    difficulty: 'Beginner'
  },
  {
    name: 'When',
    description: 'Point to your wrist where a watch would be, with a questioning expression.',
    category: 'questions',
    difficulty: 'Beginner'
  },
  {
    name: 'Why',
    description: 'Point your middle finger to your temple and then outward, with a questioning expression.',
    category: 'questions',
    difficulty: 'Intermediate'
  },
  {
    name: 'How',
    description: 'Flatten your dominant hand and place it on your non-dominant palm, then move both in a circular motion.',
    category: 'questions',
    difficulty: 'Intermediate'
  },
  {
    name: 'Who',
    description: 'Form an "L" shape with your thumb and index finger, then move it from your chin outward.',
    category: 'questions',
    difficulty: 'Intermediate'
  }
];