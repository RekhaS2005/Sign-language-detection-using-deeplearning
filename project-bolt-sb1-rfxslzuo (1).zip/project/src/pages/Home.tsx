import React from 'react';
import { Link } from 'react-router-dom';
import { Hand, BookOpen, Info } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="flex flex-col">
      <section className="bg-gradient-to-br from-indigo-600 to-purple-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="md:flex md:items-center md:justify-between">
            <div className="md:w-1/2 space-y-6">
              <h1 className="text-4xl md:text-5xl font-bold leading-tight">
                Sign Language Detection Using Deep Learning
              </h1>
              <p className="text-xl md:text-2xl text-indigo-100">
                Break communication barriers with real-time sign language detection and translation.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 mt-8">
                <Link
                  to="/detection"
                  className="bg-white text-indigo-700 hover:bg-indigo-50 font-medium py-3 px-6 rounded-lg shadow-md transition-all duration-200 text-center"
                >
                  Start Detection
                </Link>
                <Link
                  to="/learn"
                  className="bg-indigo-800 bg-opacity-50 hover:bg-opacity-70 text-white font-medium py-3 px-6 rounded-lg shadow-md transition-all duration-200 text-center"
                >
                  Learn Sign Language
                </Link>
              </div>
            </div>
            <div className="hidden md:block md:w-1/2 mt-10 md:mt-0">
              <img
                src="https://images.pexels.com/photos/6963944/pexels-photo-6963944.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                alt="Sign language illustration"
                className="w-full h-auto rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-indigo-50 rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow duration-200">
              <div className="h-12 w-12 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 mb-5">
                <Hand size={24} />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Capture Signs</h3>
              <p className="text-gray-600">
                Position your hands in front of your webcam and perform sign language gestures. Our system will capture the movement in real-time.
              </p>
            </div>
            <div className="bg-purple-50 rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow duration-200">
              <div className="h-12 w-12 bg-purple-100 rounded-full flex items-center justify-center text-purple-600 mb-5">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 2c1.4 0 2.8.7 3.6 1.9l.4.6c.7 1.1 1.7 1.9 2.9 2.2l.7.1c1.8.5 3 2.1 3 4 0 1.4-.7 2.8-1.9 3.6l-.6.4c-1.1.7-1.9 1.7-2.2 2.9l-.1.7c-.5 1.8-2.1 3-4 3-1.4 0-2.8-.7-3.6-1.9l-.4-.6c-.7-1.1-1.7-1.9-2.9-2.2l-.7-.1c-1.8-.5-3-2.1-3-4 0-1.4.7-2.8 1.9-3.6l.6-.4c1.1-.7 1.9-1.7 2.2-2.9l.1-.7c.5-1.8 2.1-3 4-3z"></path>
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">AI Processing</h3>
              <p className="text-gray-600">
                Our deep learning model analyzes the video feed, identifies hand positions, and matches them against trained sign language patterns.
              </p>
            </div>
            <div className="bg-teal-50 rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow duration-200">
              <div className="h-12 w-12 bg-teal-100 rounded-full flex items-center justify-center text-teal-600 mb-5">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="3" width="18" height="18" rx="2"></rect>
                  <path d="M7 7h10"></path>
                  <path d="M7 12h10"></path>
                  <path d="M7 17h10"></path>
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Instant Translation</h3>
              <p className="text-gray-600">
                The detected signs are translated into text in real-time, providing instant communication bridging between sign language and written text.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-6">Ready to Get Started?</h2>
          <p className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto">
            Explore our sign language detection tool, learn new signs, or understand how our technology works.
          </p>
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <Link
              to="/detection"
              className="flex flex-col items-center justify-center p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-200"
            >
              <Hand size={32} className="text-indigo-600 mb-4" />
              <h3 className="text-lg font-semibold text-gray-800">Start Detection</h3>
              <p className="text-gray-600 mt-2 text-sm">Try our real-time sign language detector</p>
            </Link>
            <Link
              to="/learn"
              className="flex flex-col items-center justify-center p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-200"
            >
              <BookOpen size={32} className="text-purple-600 mb-4" />
              <h3 className="text-lg font-semibold text-gray-800">Learn Signs</h3>
              <p className="text-gray-600 mt-2 text-sm">Browse our library of common sign language gestures</p>
            </Link>
            <Link
              to="/about"
              className="flex flex-col items-center justify-center p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-200"
            >
              <Info size={32} className="text-teal-600 mb-4" />
              <h3 className="text-lg font-semibold text-gray-800">About</h3>
              <p className="text-gray-600 mt-2 text-sm">Learn how our technology works</p>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;