import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { signDictionary } from '../data/signData';

const Learn: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [currentCategory, setCurrentCategory] = useState<string | null>(null);
  
  const categories = [
    { id: 'alphabet', name: 'Alphabet' },
    { id: 'numbers', name: 'Numbers' },
    { id: 'common', name: 'Common Phrases' },
    { id: 'greetings', name: 'Greetings' },
    { id: 'emotions', name: 'Emotions' },
    { id: 'questions', name: 'Questions' },
  ];

  const filteredSigns = searchTerm 
    ? signDictionary.filter(sign => 
        sign.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        sign.description.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : currentCategory 
      ? signDictionary.filter(sign => sign.category === currentCategory)
      : signDictionary;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-8">Learn Sign Language</h1>
      
      <div className="mb-8">
        <div className="relative max-w-md mx-auto md:mx-0">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            placeholder="Search signs..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              if (e.target.value) setCurrentCategory(null);
            }}
          />
        </div>
      </div>
      
      <div className="flex flex-wrap gap-2 mb-8">
        <button
          className={`px-4 py-2 rounded-full text-sm font-medium ${
            currentCategory === null && !searchTerm
              ? 'bg-indigo-100 text-indigo-800'
              : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
          }`}
          onClick={() => {
            setCurrentCategory(null);
            setSearchTerm('');
          }}
        >
          All Signs
        </button>
        
        {categories.map(category => (
          <button
            key={category.id}
            className={`px-4 py-2 rounded-full text-sm font-medium ${
              currentCategory === category.id
                ? 'bg-indigo-100 text-indigo-800'
                : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
            }`}
            onClick={() => {
              setCurrentCategory(category.id);
              setSearchTerm('');
            }}
          >
            {category.name}
          </button>
        ))}
      </div>
      
      {filteredSigns.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredSigns.map((sign, index) => (
            <div key={index} className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-200">
              <div className="p-4">
                <div className="uppercase tracking-wide text-sm text-indigo-600 font-semibold">
                  {sign.category}
                </div>
                <h3 className="mt-1 text-xl font-semibold text-gray-900">{sign.name}</h3>
                <p className="mt-2 text-gray-600">{sign.description}</p>
              </div>
              <div className="bg-gray-50 px-4 py-3 flex justify-between items-center">
                <span className="text-sm font-medium text-gray-500">Difficulty: {sign.difficulty}</span>
                <button className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-md text-sm font-medium hover:bg-indigo-100 transition-colors duration-150">
                  Learn More
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <div className="text-gray-400 mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h3 className="text-lg font-medium text-gray-900">No signs found</h3>
          <p className="text-gray-500 mt-2">Try a different search term or category</p>
        </div>
      )}
    </div>
  );
};

export default Learn;