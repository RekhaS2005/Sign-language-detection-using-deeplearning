import React, { useRef, useState, useEffect } from 'react';
import { AlertCircle, Camera, CameraOff, RefreshCw } from 'lucide-react';
import DetectionResults from '../components/DetectionResults';
import { startDetection, stopDetection } from '../utils/detectionService';

const Detection: React.FC = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDetecting, setIsDetecting] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [detectedSigns, setDetectedSigns] = useState<Array<{sign: string, confidence: number}>>([]);
  const [loading, setLoading] = useState(false);

  // Initialize webcam
  const initializeCamera = async () => {
    if (!videoRef.current) {
      console.warn('Video element not yet available.');
      return;
    }

    setLoading(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: 640, height: 480 }
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setCameraActive(true);
        setErrorMessage(null);
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
      setErrorMessage('Unable to access camera. Please make sure your camera is connected and permissions are granted.');
      setCameraActive(false);
    } finally {
      setLoading(false);
    }
  };

  // Auto-initialize camera on component mount
  useEffect(() => {
    initializeCamera();
    // Cleanup function to stop camera when component unmounts
    return () => {
      stopCamera();
    };
  }, []); // Empty dependency array means this runs once on mount

  // Stop the camera
  const stopCamera = () => {
    if (!videoRef.current || !videoRef.current.srcObject) return;
    
    const stream = videoRef.current.srcObject as MediaStream;
    const tracks = stream.getTracks();
    
    tracks.forEach(track => track.stop());
    videoRef.current.srcObject = null;
    setCameraActive(false);
    
    if (isDetecting) {
      stopDetection();
      setIsDetecting(false);
    }
  };

  // Toggle detection
  const toggleDetection = () => {
    if (!cameraActive) return;
    
    if (isDetecting) {
      stopDetection();
      setIsDetecting(false);
    } else {
      if (videoRef.current && canvasRef.current) {
        // Simulating detection by generating random results periodically
        const detectionInterval = startDetection(videoRef.current, canvasRef.current, (results) => {
          setDetectedSigns(results);
        });
        
        setIsDetecting(true);
      }
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Sign Language Detection</h1>
      
      <div className="grid md:grid-cols-5 gap-8">
        <div className="md:col-span-3 bg-white p-4 rounded-xl shadow-md">
          <div className="relative">
            {errorMessage && (
              <div className="bg-red-50 text-red-700 p-4 rounded-md mb-4 flex items-start">
                <AlertCircle className="h-5 w-5 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}
            
            <div className="relative bg-gray-100 rounded-lg overflow-hidden aspect-video flex items-center justify-center">
              {loading ? (
                <div className="flex flex-col items-center justify-center p-8">
                  <RefreshCw className="h-10 w-10 text-indigo-500 animate-spin mb-4" />
                  <p className="text-gray-600">Initializing camera...</p>
                </div>
              ) : (
                <>
                  <video 
                    ref={videoRef}
                    className={`w-full h-full object-cover ${!cameraActive && 'hidden'}`}
                    autoPlay
                    playsInline
                    muted
                  />
                  <canvas 
                    ref={canvasRef}
                    className="absolute top-0 left-0 w-full h-full"
                  />
                  {!cameraActive && (
                    <div className="flex flex-col items-center justify-center p-8">
                      <CameraOff className="h-16 w-16 text-gray-400 mb-4" />
                      <p className="text-gray-600 mb-4">Camera is currently turned off</p>
                      <button
                        onClick={initializeCamera}
                        className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg shadow-sm transition-colors duration-150 flex items-center"
                        disabled={loading}
                      >
                        <Camera className="h-5 w-5 mr-2" />
                        Turn on camera
                      </button>
                    </div>
                  )}
                </>
              )}
            </div>
            
            <div className="mt-4 flex justify-between items-center">
              <div className="flex space-x-3">
                {cameraActive && (
                  <button
                    onClick={toggleDetection}
                    className={`${
                      isDetecting 
                        ? 'bg-red-600 hover:bg-red-700' 
                        : 'bg-indigo-600 hover:bg-indigo-700'
                    } text-white font-medium py-2 px-4 rounded-lg shadow-sm transition-colors duration-150`}
                    disabled={loading}
                  >
                    {isDetecting ? 'Stop Detection' : 'Start Detection'}
                  </button>
                )}
                
                {cameraActive ? (
                  <button
                    onClick={stopCamera}
                    className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded-lg shadow-sm transition-colors duration-150"
                    disabled={loading}
                  >
                    Turn off camera
                  </button>
                ) : (
                  <button
                    onClick={initializeCamera}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg shadow-sm transition-colors duration-150 flex items-center"
                    disabled={loading}
                  >
                    <Camera className="h-5 w-5 mr-2" />
                    Turn on camera
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
        
        <div className="md:col-span-2">
          <DetectionResults results={detectedSigns} isDetecting={isDetecting} />
        </div>
      </div>
      
      <div className="mt-8 bg-white p-6 rounded-xl shadow-md">
        <h2 className="text-xl font-bold text-gray-800 mb-4">How to Use</h2>
        <ol className="list-decimal pl-5 space-y-2 text-gray-700">
          <li>Position yourself in frame so your hands are clearly visible</li>
          <li>Click "Start Detection" to begin sign language recognition</li>
          <li>Perform ASL signs and watch the detection results appear in real-time</li>
          <li>The confidence level shows how certain the AI is about each detection</li>
        </ol>
      </div>
    </div>
  );
};

export default Detection;