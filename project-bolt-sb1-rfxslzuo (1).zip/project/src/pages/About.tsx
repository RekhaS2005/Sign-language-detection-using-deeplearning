import React from 'react';

const About: React.FC = () => {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">About SignSense</h1>
      
      <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
        <div className="p-6">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Our Mission</h2>
          <p className="text-gray-600 mb-4">
            SignSense was created with a simple but powerful mission: to break down communication barriers between the deaf and hearing communities using the latest advances in artificial intelligence and computer vision.
          </p>
          <p className="text-gray-600">
            We believe that technology should be inclusive and accessible to everyone. By developing tools that can recognize and translate sign language in real-time, we aim to create a more connected world where language differences don't stand in the way of human connection.
          </p>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
        <div className="p-6">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">The Technology</h2>
          
          <h3 className="text-xl font-medium text-gray-800 mt-6 mb-3">Deep Learning Model</h3>
          <p className="text-gray-600 mb-4">
            Our sign language detection system uses a state-of-the-art deep learning model based on convolutional neural networks (CNNs) and transformers specifically designed for computer vision tasks. The model has been trained on thousands of examples of American Sign Language (ASL) signs to recognize hand shapes, movements, and gestures with high accuracy.
          </p>
          
          <h3 className="text-xl font-medium text-gray-800 mt-6 mb-3">Real-time Processing</h3>
          <p className="text-gray-600 mb-4">
            The system processes video input frame-by-frame to detect and track hand movements in real-time. Using TensorFlow.js, we're able to run these complex algorithms directly in your browser, ensuring privacy and eliminating the need for server-side processing.
          </p>
          
          <h3 className="text-xl font-medium text-gray-800 mt-6 mb-3">Continuous Learning</h3>
          <p className="text-gray-600">
            Our model is constantly improving through continuous learning techniques. As more people use the system, we can anonymously collect performance data to enhance the accuracy and broaden the range of signs that can be recognized.
          </p>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
        <div className="p-6">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Future Development</h2>
          <p className="text-gray-600 mb-3">
            We're actively working on expanding SignSense with new features:
          </p>
          <ul className="list-disc pl-5 space-y-2 text-gray-600 mb-4">
            <li>Support for additional sign languages beyond ASL</li>
            <li>Two-way translation: text-to-sign language visualization</li>
            <li>Mobile applications for iOS and Android</li>
            <li>Integration with video conferencing platforms</li>
            <li>Offline functionality for use without internet connection</li>
            <li>Educational tools for learning sign language</li>
          </ul>
          <p className="text-gray-600">
            Our roadmap is guided by feedback from both the deaf community and sign language interpreters to ensure we're building technology that truly serves their needs.
          </p>
        </div>
      </div>
      
      <div className="bg-indigo-50 rounded-xl shadow-sm overflow-hidden">
        <div className="p-6">
          <h2 className="text-2xl font-semibold text-indigo-800 mb-4">Get Involved</h2>
          <p className="text-indigo-700 mb-4">
            We welcome contributions from developers, designers, sign language experts, and anyone passionate about accessibility. If you'd like to contribute to the project or provide feedback, please reach out to us.
          </p>
          <div className="mt-4">
            <a 
              href="#" 
              className="inline-flex items-center px-4 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              Contact Us
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;