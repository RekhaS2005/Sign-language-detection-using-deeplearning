import React, { useState, useEffect } from 'react';

interface DetectionResult {
  sign: string;
  confidence: number;
}

interface DetectionResultsProps {
  results: DetectionResult[];
  isDetecting: boolean;
}

const DetectionResults: React.FC<DetectionResultsProps> = ({ results, isDetecting }) => {
  const [history, setHistory] = useState<DetectionResult[]>([]);
  
  // Update history when new results come in with high confidence
  useEffect(() => {
    if (results.length > 0 && results[0].confidence > 0.7) {
      setHistory(prev => {
        // Add new result at beginning, limit to 10 items
        const newHistory = [results[0], ...prev];
        return newHistory.slice(0, 10);
      });
    }
  }, [results]);

  // Clear history when detection is stopped
  useEffect(() => {
    if (!isDetecting) {
      // Keep history when detection is stopped
    }
  }, [isDetecting]);

  const getConfidenceColor = (confidence: number) => {
    if (confidence > 0.8) return 'bg-green-500';
    if (confidence > 0.6) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="h-full flex flex-col">
      <div className="bg-white p-4 rounded-xl shadow-md mb-4">
        <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
          <span>Current Detection</span>
          {isDetecting && (
            <span className="ml-3 inline-block h-3 w-3 rounded-full bg-green-500 animate-pulse"></span>
          )}
        </h2>
        
        {isDetecting ? (
          results.length > 0 ? (
            <div className="space-y-4">
              <div className="p-4 bg-indigo-50 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-2xl font-bold text-indigo-800">{results[0].sign}</h3>
                  <span className="text-sm font-medium text-indigo-700">
                    {(results[0].confidence * 100).toFixed(1)}% confident
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className={`h-2.5 rounded-full ${getConfidenceColor(results[0].confidence)}`} 
                    style={{ width: `${results[0].confidence * 100}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-2">
                {results.slice(1, 5).map((result, index) => (
                  <div key={index} className="bg-gray-50 p-3 rounded-md">
                    <div className="flex justify-between items-center">
                      <span className="font-medium text-gray-700">{result.sign}</span>
                      <span className="text-xs text-gray-500">
                        {(result.confidence * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                      <div 
                        className={`h-1.5 rounded-full ${getConfidenceColor(result.confidence)}`} 
                        style={{ width: `${result.confidence * 100}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-6 text-gray-500">
              <p>Waiting for signs to detect...</p>
              <p className="text-sm mt-2">Make sign gestures in front of the camera</p>
            </div>
          )
        ) : (
          <div className="text-center py-6 text-gray-500">
            <p>Detection is not active</p>
            <p className="text-sm mt-2">Start detection to see results</p>
          </div>
        )}
      </div>
      
      <div className="bg-white p-4 rounded-xl shadow-md flex-grow">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">Recent Detections</h2>
        
        {history.length > 0 ? (
          <div className="space-y-2">
            {history.map((item, index) => (
              <div key={index} className="flex justify-between items-center p-2 border-b border-gray-100">
                <div className="font-medium">{item.sign}</div>
                <div className="text-sm text-gray-500">
                  {(item.confidence * 100).toFixed(1)}%
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6 text-gray-500">
            <p>No detections recorded yet</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default DetectionResults;